package com.example.demogame.cartProduct;

import org.springframework.stereotype.Service;

@Service
public class CartProductService {
    private CartProductRepository cartProductRepository;
}
