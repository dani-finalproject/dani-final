package com.example.demogame.productOrderCon;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductOrderConRepository extends JpaRepository<ProductOrderCon, Long> {
}
